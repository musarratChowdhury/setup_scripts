This directory "runtime/syntax/shared" contains Vim script files that are
generated or used by more than one syntax file.
